# EMEA EXECUTIVES — Docs Index

Centralized index of all documents, playbooks, and resources for outreach and executive engagement.

## Core Materials
- **EMEA_Executives_Brief.docx** — Editable one-page executive brief
- **EMEA_Executives_Brief.pdf** — Executive brief (distribution-ready PDF)
- **EMEA_Executives_Deck.pptx** (in `/deck/`) — Multi-slide investor/client deck

## Social & Engagement
- **LinkedIn_Posts.docx** — Three crafted LinkedIn posts
- **LinkedIn_Posts.pdf** — Posts in distribution format
- **LinkedIn_Replies_Playbook.docx** — Reply templates (editable)
- **LinkedIn_Replies_Playbook.pdf** — Reply templates (PDF)
- **LinkedIn PNG Visuals** (in `/social/`) — Branded graphics for LinkedIn

## Discovery Tools
- **CLIENT_DISCOVERY_QUESTIONS.md** — Intake questions for clients (Markdown)
- **CLIENT_DISCOVERY_QUESTIONS.pdf** — Intake questions for clients (PDF)
- **CANDIDATE_DISCOVERY_QUESTIONS.md** — Discovery questions for candidates (Markdown)
- **CANDIDATE_DISCOVERY_QUESTIONS.pdf** — Discovery questions for candidates (PDF)

## Counter-Questions Playbooks
- **CLIENT_COUNTER_QUESTIONS_PLAYBOOK.pdf** — Push deeper with client answers
- **CANDIDATE_COUNTER_QUESTIONS_PLAYBOOK.pdf** — Push deeper with candidate answers

## Reference
- **README_Outreach_Pack.txt** — Pack usage guide
- **README.md** (root) — Repo overview
- **CONTRIBUTING.md** — How to update materials
- **CHANGELOG.md** — Version history
- **LICENSE** — License terms (MIT)

---
> ✅ Use this index as a quick navigator when working with outreach and engagement materials.
