# EMEA EXECUTIVES — Outreach Pack

Executive-ready outreach materials for leaders across EMEA. This repository provides a reusable, version-controlled template for presentations, briefs, social assets, and engagement playbooks.

## Structure
```
.
├── assets/                      # Brand assets
│   └── logo.png
├── deck/                        # Presentation materials
│   └── EMEA_Executives_Deck.pptx
├── brief/                       # One-page executive brief (editable)
│   └── EMEA_Executives_Brief.docx
├── docs/                        # PDFs + reference docs
│   ├── EMEA_Executives_Brief.pdf
│   ├── LinkedIn_Posts.pdf
│   ├── LinkedIn_Replies_Playbook.pdf
│   └── README_Outreach_Pack.txt
├── social/                      # LinkedIn PNG visuals + copy (docx)
│   ├── LinkedIn_Posts.docx
│   ├── post1_launch.png
│   ├── post2_problem_solution.png
│   ├── post2_alt.png
│   └── post3_traction_invitation.png
├── playbooks/                   # Comment reply templates
│   └── LinkedIn_Replies_Playbook.docx
└── LICENSE
```

## Usage
- **Deck** → Present in client/investor meetings; export to PDF for circulation.
- **Brief** → Share as a concise leave-behind with target stakeholders.
- **Social** → Post the PNGs with the provided copy to drive awareness.
- **Playbooks** → Keep tone consistent when replying on LinkedIn.

## Brand Guidelines (Essentials)
- Tone: professional, confident, concise.
- Palette: deep navy backgrounds; cyan/emerald accents.
- Always include the EMEA EXECUTIVES logo where appropriate.

## Versioning Workflow
1. Create a new branch (`feature/update-brief`, `creative/new-visuals`, etc.).
2. Update source files (DOCX/PPTX/PNGs) in their respective folders.
3. Export updated PDFs into `/docs` for distribution.
4. Open a PR with a short executive summary of changes.

## Changelog
See [`CHANGELOG.md`](CHANGELOG.md) for release notes.

## License
MIT — see [`LICENSE`](LICENSE). Brand assets are © EMEA EXECUTIVES; use permitted for this outreach pack.
