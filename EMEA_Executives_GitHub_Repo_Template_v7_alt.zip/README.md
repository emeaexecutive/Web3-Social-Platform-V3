# EMEA EXECUTIVES — Outreach Toolkit

Version: v7 — August 26, 2025
