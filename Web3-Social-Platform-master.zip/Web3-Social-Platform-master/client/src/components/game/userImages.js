import jackImg from '../../assets/img/jack-rounded-img@2x.png';
import kingImg from '../../assets/img/king-rounded-img@2x.png';
import queenImg from '../../assets/img/queen-rounded-img@2x.png';
import queen2Img from '../../assets/img/queen2-rounded-img@2x.png';

export default [null, jackImg, queen2Img, kingImg, jackImg, queenImg];
