import { createContext } from 'react';

const locaContext = createContext();

export default locaContext;
