# Changelog

All notable changes to this outreach pack will be documented in this file.

## 2025-08-26 — Initial Release
- Added PPTX deck
- Added executive brief (DOCX + PDF)
- Added LinkedIn posts (DOCX + PDF)
- Added LinkedIn reply playbook (DOCX + PDF)
- Added social PNG visuals
- Added repo README, LICENSE, and .gitignore
