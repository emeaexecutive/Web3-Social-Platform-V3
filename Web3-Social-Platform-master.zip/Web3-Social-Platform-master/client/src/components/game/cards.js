import c2 from '../../assets/game/cards-svg/c2.svg';
import c3 from '../../assets/game/cards-svg/c3.svg';
import c4 from '../../assets/game/cards-svg/c4.svg';
import c5 from '../../assets/game/cards-svg/c5.svg';
import c6 from '../../assets/game/cards-svg/c6.svg';
import c7 from '../../assets/game/cards-svg/c7.svg';
import c8 from '../../assets/game/cards-svg/c8.svg';
import c9 from '../../assets/game/cards-svg/c9.svg';
import c10 from '../../assets/game/cards-svg/c10.svg';
import cJ from '../../assets/game/cards-svg/cJ.svg';
import cQ from '../../assets/game/cards-svg/cQ.svg';
import cK from '../../assets/game/cards-svg/cK.svg';
import cA from '../../assets/game/cards-svg/cA.svg';
import d2 from '../../assets/game/cards-svg/d2.svg';
import d3 from '../../assets/game/cards-svg/d3.svg';
import d4 from '../../assets/game/cards-svg/d4.svg';
import d5 from '../../assets/game/cards-svg/d5.svg';
import d6 from '../../assets/game/cards-svg/d6.svg';
import d7 from '../../assets/game/cards-svg/d7.svg';
import d8 from '../../assets/game/cards-svg/d8.svg';
import d9 from '../../assets/game/cards-svg/d9.svg';
import d10 from '../../assets/game/cards-svg/d10.svg';
import dJ from '../../assets/game/cards-svg/dJ.svg';
import dQ from '../../assets/game/cards-svg/dQ.svg';
import dK from '../../assets/game/cards-svg/dK.svg';
import dA from '../../assets/game/cards-svg/dA.svg';
import h2 from '../../assets/game/cards-svg/h2.svg';
import h3 from '../../assets/game/cards-svg/h3.svg';
import h4 from '../../assets/game/cards-svg/h4.svg';
import h5 from '../../assets/game/cards-svg/h5.svg';
import h6 from '../../assets/game/cards-svg/h6.svg';
import h7 from '../../assets/game/cards-svg/h7.svg';
import h8 from '../../assets/game/cards-svg/h8.svg';
import h9 from '../../assets/game/cards-svg/h9.svg';
import h10 from '../../assets/game/cards-svg/h10.svg';
import hJ from '../../assets/game/cards-svg/hJ.svg';
import hQ from '../../assets/game/cards-svg/hQ.svg';
import hK from '../../assets/game/cards-svg/hK.svg';
import hA from '../../assets/game/cards-svg/hA.svg';
import s2 from '../../assets/game/cards-svg/s2.svg';
import s3 from '../../assets/game/cards-svg/s3.svg';
import s4 from '../../assets/game/cards-svg/s4.svg';
import s5 from '../../assets/game/cards-svg/s5.svg';
import s6 from '../../assets/game/cards-svg/s6.svg';
import s7 from '../../assets/game/cards-svg/s7.svg';
import s8 from '../../assets/game/cards-svg/s8.svg';
import s9 from '../../assets/game/cards-svg/s9.svg';
import s10 from '../../assets/game/cards-svg/s10.svg';
import sJ from '../../assets/game/cards-svg/sJ.svg';
import sQ from '../../assets/game/cards-svg/sQ.svg';
import sK from '../../assets/game/cards-svg/sK.svg';
import sA from '../../assets/game/cards-svg/sA.svg';
import hiddenhidden from '../../assets/game/card_back.png';

export default {
  hiddenhidden,
  c2,
  c3,
  c4,
  c5,
  c6,
  c7,
  c8,
  c9,
  c10,
  cJ,
  cQ,
  cK,
  cA,
  d2,
  d3,
  d4,
  d5,
  d6,
  d7,
  d8,
  d9,
  d10,
  dJ,
  dQ,
  dK,
  dA,
  h2,
  h3,
  h4,
  h5,
  h6,
  h7,
  h8,
  h9,
  h10,
  hJ,
  hQ,
  hK,
  hA,
  s2,
  s3,
  s4,
  s5,
  s6,
  s7,
  s8,
  s9,
  s10,
  sJ,
  sQ,
  sK,
  sA,
};
