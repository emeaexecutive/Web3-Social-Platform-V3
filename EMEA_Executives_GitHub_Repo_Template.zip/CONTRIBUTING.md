# Contributing

Thanks for helping improve the EMEA EXECUTIVES outreach pack!

## Principles
- Keep tone consistent (professional, confident, concise).
- Maintain visual consistency (logo placement, colors, spacing).
- Prefer short, scannable bullet points over long paragraphs.

## Process
1. Create a feature branch.
2. Make edits in the appropriate folder (deck/brief/social/playbooks).
3. Export final PDFs to `/docs`.
4. Update `CHANGELOG.md` with a short summary.
5. Submit a PR for review.
