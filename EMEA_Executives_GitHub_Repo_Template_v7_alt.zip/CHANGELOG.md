## v7 — August 26, 2025
- Added PDFs/MDs, social images, and index.

## v8 — Upcoming
- Heatmaps, scorecards, case studies.
